import { hash, hashSync } from "bcrypt"
import { createHash } from "crypto";

export const hashPasswordTransform = {
    to(password: string): string {
        return hashSync(password, 10);
    },
    from(hash: string): string {
        return hash;
    },
    toMD5(password: string): string {
        const md5 = data => createHash('md5').update(data).digest("hex")
        return md5(password).toString();
    }
}