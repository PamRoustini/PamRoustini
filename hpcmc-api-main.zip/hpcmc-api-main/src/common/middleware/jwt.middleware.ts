import { Injectable, NestMiddleware, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { Request, Response, NextFunction } from 'express';

@Injectable()
export class JwtMiddleware implements NestMiddleware {
  constructor(private readonly jwtService: JwtService) {}

  use(req: Request, res: Response, next: NextFunction) {
    /* const { path, method } = req;
    // console.log('path =>', path);
    // Verifique se a requisição é para o endpoint de login ou refresh token
    const isLoginOrRefreshRequest = path === '/login' || path === '/refresh-token';
    
    if (isLoginOrRefreshRequest && method === 'POST') {
      // Se for uma requisição de login ou refresh token, passe para o próximo middleware sem validar o token
      next();
      return;
    } */

    const tokenHeader = req.headers['authorization'];

    if (!tokenHeader) {
        throw new UnauthorizedException('Token não encontrado');
    }
    console.log('Token =>', tokenHeader.replace('Bearer','').trim());
    // token.replace('Bearer','').trim();
    const token = tokenHeader.split(' ')[1];
    const isTokenValid = this.jwtService.verify(token, {
        secret: process.env.JWT_SECRET,
        ignoreExpiration: true,
    });
    console.log('isTokenValid =>', isTokenValid);
    if (token) {
        try {
        const isTokenValid = this.jwtService.verify(token, {
            secret: process.env.JWT_SECRET,
            ignoreExpiration: true,
        });
        } catch (err) {
            // console.log(err.name);
            // console.log(err.message);
            // console.log(err.expiredAt);
            if (err.name === 'JsonWebTokenError') {
                throw new UnauthorizedException('Assinatura Inválida');
            }
            if (err.name === 'TokenExpiredError') {
                throw new UnauthorizedException('Token Expirado');
            }
            throw new UnauthorizedException(err.name);
        }
    }
    next();
  }
}