import { AuthPayLoad } from "./auth-payload";

export class AuthType {
    id: string;
    uuid: string;
    username: string;
    first_name: string;
    last_name: string;
    email: string;
    token: AuthPayLoad;
       
}