export class AuthInput {
    email: string;
    password: string;
}