export class AuthPayLoad {
    access_token: string;
    refresh_token: string; 
}