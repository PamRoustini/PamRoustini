import { Column, CreateDateColumn, DeleteDateColumn, Entity, JoinColumn, ManyToOne, OneToMany, OneToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
// import { hashPasswordTransform } from "src/common/helpers/crypto";

@Entity('tb_users')
export class User {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({ length: 36, nullable: true })
    uuid: string;

    @Column({ length: 60 })
    username: string;

    @Column({ 
        length: 50,
        // transformer: hashPasswordTransform,    
    })
    userpass: string;

    @Column({ length: 120, nullable: true, default: '' })
    first_name: string;

    @Column({ length: 120, nullable: true, default: '' })
    last_name: string;

    @Column({ length: 150, nullable: true, default: '' })
    email: string;

    @Column({ length: 25, nullable: true, default: '' })
    phonenumber: string;

    @Column({ length: 25, nullable: true, default: '' })
    whatsappnumber: string;

    @Column({ length: 255, nullable: true, default: '' })
    avatar: string;

    @Column('tinyint', {
        nullable: false,
        default: () => 1,
        name: 'state',
        comment: 'Active-Inactive registration'
    })
    state: number;

    @Column('tinyint', {
        nullable: false,
        default: () => 1,
        name: 'active',
        comment: 'Active-Inactive registration'
    })
    active: number;

    @Column('tinyint', {
        nullable: false,
        default: () => 0,
        name: 'excluded',
        comment: 'Deleted record'
    })
    excluded: number;

    @Column({precision: 0, name: 'title_function_id', nullable: true, default: 0})
    title_function_id: number;

    @Column({precision: 0, name: 'subscription_id', nullable: true, default: 0})
    subscription_id: number;

    @CreateDateColumn({
        type: 'timestamp',
        nullable: true,
        default: () => "CURRENT_TIMESTAMP()",
        name: 'created_at',
        precision: 0,
        comment: 'Creation date'
    })
    created_at: Date;

    @UpdateDateColumn({
        type: 'timestamp',
        nullable: true,
        default: () => "CURRENT_TIMESTAMP()", onUpdate: "CURRENT_TIMESTAMP()",
        name: 'updated_at',
        precision: 0,
        comment: 'Update date',
    })
    updated_at: Date;

    @DeleteDateColumn({
        type: 'timestamp',
        nullable: true,
        default: () => "CURRENT_TIMESTAMP()", onUpdate: "CURRENT_TIMESTAMP()",
        name: 'deleted_at',
        precision: 0,
        comment: 'Update date',
    })
    deleted_at: Date;

    @UpdateDateColumn({
        type: 'timestamp',
        nullable: true,
        default: () => "CURRENT_TIMESTAMP()", onUpdate: "CURRENT_TIMESTAMP()",
        name: 'last_updated',
        precision: 0,
        comment: 'Update date',
    })
    last_updated: Date;

}
