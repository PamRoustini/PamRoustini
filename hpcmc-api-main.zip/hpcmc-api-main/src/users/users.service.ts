import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { User } from './entities/user.entity';
import { Repository } from 'typeorm';
import { AuthInput } from './dto/auth-input';
import { AuthType } from './dto/auth-type';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)
    private userRepository: Repository<User>
  ) {}

  async findAgentByUserName(userName: string): Promise<User | undefined> {
    const agent = await this.userRepository.findOne({
        where: {username: userName}
    });
    if (!agent) {
        throw new NotFoundException('user not found');
    }        
    return agent;
  } 

  async findAgentByUserEmail(email: string): Promise<User | undefined> {
    const agent = await this.userRepository.findOne({
        where: {email: email}
    });
    if (!agent) {
        throw new NotFoundException('user not found');
    }        
    return agent;
  } 

  async findAgentAuthentication(userName: string): Promise<User | undefined> {
      const agent = await this.userRepository.findOne({
          select: ["id", "uuid", "username", "userpass", "first_name", "last_name", "phonenumber" , "whatsappnumber"],          
          where: {username: userName}
      });
      if (!agent) {
          throw new NotFoundException('Agent not found');
      }        
      return agent;
  }

  async findUserById(id: number): Promise<User> {
    const agent = await this.userRepository.findOne({
      where: { 'id': id}
    });

    if (!agent) {
        throw new NotFoundException('User not found');
    }
    return agent;
  }
  
  
  async findAll(): Promise<User[]> {
    return await this.userRepository.createQueryBuilder("user")
    // .select([
      //     "tb_users.id", "tb_users.uuid", "tb_users.username", "tb_users.first_name", , "tb_users.last_name", , "tb_users.email", , "tb_users.phone_number", "tb_users.whatsappnumber", "tb_users.state", "tb_users.active", "tb_users.title_function_id",
      //   ])
      .select([
        "user.id", "user.uuid", "user.username", "user.first_name", "user.last_name", "user.email", "user.phonenumber", "user.whatsappnumber", "user.state", "user.active", "user.avatar", "user.title_function_id", 
      ])
      .where({ active: 1 })
      .orderBy("user.id", "ASC")
      .getMany();
  }

  async ValidateAgent(data: AuthInput): Promise<AuthType> {
    console.log('ValidateAgent Data.User =>', data.email, 'Data.Password =>', data.password);
        
    const user = await this.findAgentByUserEmail(data.email);
    // const user = await this.findAgentByUserName('sysadmin');
    //* const passWD = hashPasswordTransform.toMD5(data.userpass);

    // const validPassword = compareSync(data.password, agent.senha);
    //* const validPassword = (passWD === user.userpass);

    //* if (!validPassword) {
    //     throw new UnauthorizedException('Incorret paswword');
    // }

    const { userpass, ...result } = user;
    const token = await this.jwtToken(user);

    //* await this.tokenService.save(token, data.username)
    
    
    return {
        id: result.id.toString(),
        uuid: result.uuid,
        username: result.username,
        first_name: result.first_name,
        last_name: result.last_name,
        email: result.email,
        token: {
            access_token: token,
            refresh_token: token,
        },
    }

  }

  async login(user: any) {
    // const payload = { username: user.login, sub: user.id };
    // const token = this.jwtService.sign(payload)
    // this.tokenService.save(token, user.login)
    // return {
    //   access_token: token
    // };
  }

  async loginToken(token: string) {
    // let usuario: User = await this.tokenService.getUsuarioByToken(token)
    // if (usuario){
    //   return this.login(usuario)
    // } else {
    //   return new HttpException({
    //     errorMessage: 'Token inválido'
    //   }, HttpStatus.UNAUTHORIZED)
    // }
  }

  async checkToken(token: string): Promise<any> {
    // const decodedToken = await this.jwtService.verifyAsync(token);

    // if (decodedToken) {
    //   return { isValid: true, decodedToken };
    // } else {
    //   return { isValid: false };
    // }
  }

  private async jwtToken(user: User): Promise<string> {
    const payload = { sub: user.id, name: user.username};
    return "";
    //* return this.jwtService.signAsync(payload);
  }

  create(createUserDto: CreateUserDto) {
    return 'This action adds a new user';
  }

  findOne(id: number) {
    return `This action returns a #${id} user`;
  }

  update(id: number, updateUserDto: UpdateUserDto) {
    return `This action updates a #${id} user`;
  }

  remove(id: number) {
    return `This action removes a #${id} user`;
  }
}
