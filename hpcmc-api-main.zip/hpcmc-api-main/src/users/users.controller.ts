import { Controller, Get, Post, Body, Patch, Param, Delete, Res, Request } from '@nestjs/common';
import { UsersService } from './users.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { AuthInput } from './dto/auth-input';
import { AuthType } from './dto/auth-type';

@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Post('login')
  public async login(@Body() data: AuthInput, @Res({ passthrough: true }) res): Promise<AuthType> {
      const response = await this.usersService.ValidateAgent(data);
      // const { password, ...result } =  response.user;
      // console.log('User =>', response.user);
      // console.log('Result =>', response);
      console.log('Token =>', response.token.access_token);

      res.header('X-Access-Token', response.token.access_token);
      return {
          id: response.id,
          uuid: response.uuid,
          username: response.username,
          first_name: response.first_name,
          last_name: response.last_name,
          email: response.email,
          token: response.token,
      }
  }

  @Post('login-token')
  async loginToken(@Request() req, @Body() data) {
      return this.usersService.loginToken(data.token);
  }
  
  @Post()
  create(@Body() createUserDto: CreateUserDto) {
    return this.usersService.create(createUserDto);
  }

  @Get()
  findAll() {
    return this.usersService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.usersService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateUserDto: UpdateUserDto) {
    return this.usersService.update(+id, updateUserDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.usersService.remove(+id);
  }
}
