import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  getHello(): string {
    return `H.P API ${process.env.VERSION_APP} ${process.env.VERSION_MONTH} ${process.env.ENVIROMENT}`;
  }
}
