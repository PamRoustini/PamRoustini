-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	8.0.35-0ubuntu0.20.04.1


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema db_cantidio_fs
--

CREATE DATABASE IF NOT EXISTS db_cantidio_fs;
USE db_cantidio_fs;

--
-- Definition of table `tb_access_permissions`
--

DROP TABLE IF EXISTS `tb_access_permissions`;
CREATE TABLE `tb_access_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `rules_id` int DEFAULT '0',
  `resource_id` int DEFAULT '0',
  `active` tinyint NOT NULL DEFAULT '1',
  `excluded` tinyint NOT NULL DEFAULT '0',
  `subscription_id` int DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `rules_id` (`rules_id`),
  KEY `resource_id` (`resource_id`),
  CONSTRAINT `tb_access_permissions_ibfk_1` FOREIGN KEY (`rules_id`) REFERENCES `tb_user_rules` (`id`),
  CONSTRAINT `tb_access_permissions_ibfk_2` FOREIGN KEY (`resource_id`) REFERENCES `tb_system_resources` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_access_permissions`
--

/*!40000 ALTER TABLE `tb_access_permissions` DISABLE KEYS */;
INSERT INTO `tb_access_permissions` (`id`,`uuid`,`rules_id`,`resource_id`,`active`,`excluded`,`subscription_id`,`created_at`,`updated_at`,`deleted_at`,`last_updated`) VALUES 
 (1,'3a41cc01-71b2-11ee-abee-f60ae0659f4b',1,1,1,0,0,'2023-10-23 14:41:19','2023-10-23 14:41:19',NULL,'2023-10-23 14:41:19');
/*!40000 ALTER TABLE `tb_access_permissions` ENABLE KEYS */;


--
-- Definition of trigger `insert_uuid_tb_access_permissions`
--

DROP TRIGGER /*!50030 IF EXISTS */ `insert_uuid_tb_access_permissions`;

DELIMITER $$

CREATE DEFINER = `usrfscais`@`%` TRIGGER `insert_uuid_tb_access_permissions` BEFORE INSERT ON `tb_access_permissions` FOR EACH ROW BEGIN
  IF new.uuid IS NULL THEN
    SET new.uuid = uuid();
  END IF;
END $$

DELIMITER ;

--
-- Definition of table `tb_access_user`
--

DROP TABLE IF EXISTS `tb_access_user`;
CREATE TABLE `tb_access_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `user_id` int DEFAULT '0',
  `rule_id` int DEFAULT '0',
  `active` tinyint NOT NULL DEFAULT '1',
  `excluded` tinyint NOT NULL DEFAULT '0',
  `subscription_id` int DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `rule_id` (`rule_id`),
  CONSTRAINT `tb_access_user_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tb_users` (`id`),
  CONSTRAINT `tb_access_user_ibfk_2` FOREIGN KEY (`rule_id`) REFERENCES `tb_user_rules` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_access_user`
--

/*!40000 ALTER TABLE `tb_access_user` DISABLE KEYS */;
INSERT INTO `tb_access_user` (`id`,`uuid`,`user_id`,`rule_id`,`active`,`excluded`,`subscription_id`,`created_at`,`updated_at`,`deleted_at`,`last_updated`) VALUES 
 (1,'1cda44bf-71a9-11ee-abee-f60ae0659f4b',1,1,1,0,0,'2023-10-23 13:36:04','2023-10-23 13:36:04',NULL,'2023-10-23 13:36:04');
/*!40000 ALTER TABLE `tb_access_user` ENABLE KEYS */;


--
-- Definition of trigger `insert_uuid_tb_access_user`
--

DROP TRIGGER /*!50030 IF EXISTS */ `insert_uuid_tb_access_user`;

DELIMITER $$

CREATE DEFINER = `usrfscais`@`%` TRIGGER `insert_uuid_tb_access_user` BEFORE INSERT ON `tb_access_user` FOR EACH ROW BEGIN
  IF new.uuid IS NULL THEN
    SET new.uuid = uuid();
  END IF;
END $$

DELIMITER ;

--
-- Definition of table `tb_system_resources`
--

DROP TABLE IF EXISTS `tb_system_resources`;
CREATE TABLE `tb_system_resources` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `description` varchar(180) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '',
  `active` tinyint NOT NULL DEFAULT '1',
  `excluded` tinyint NOT NULL DEFAULT '0',
  `subscription_id` int DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_system_resources`
--

/*!40000 ALTER TABLE `tb_system_resources` DISABLE KEYS */;
INSERT INTO `tb_system_resources` (`id`,`uuid`,`name`,`description`,`active`,`excluded`,`subscription_id`,`created_at`,`updated_at`,`deleted_at`,`last_updated`) VALUES 
 (1,'6826b551-71a4-11ee-abee-f60ae0659f4b','Insert User','Cadastrar usuários',1,0,0,'2023-10-23 13:02:23','2023-10-23 13:02:23',NULL,'2023-10-23 13:02:23');
/*!40000 ALTER TABLE `tb_system_resources` ENABLE KEYS */;


--
-- Definition of trigger `insert_uuid_tb_system_resources`
--

DROP TRIGGER /*!50030 IF EXISTS */ `insert_uuid_tb_system_resources`;

DELIMITER $$

CREATE DEFINER = `usrfscais`@`%` TRIGGER `insert_uuid_tb_system_resources` BEFORE INSERT ON `tb_system_resources` FOR EACH ROW BEGIN
  IF new.uuid IS NULL THEN
    SET new.uuid = uuid();
  END IF;
END $$

DELIMITER ;

--
-- Definition of table `tb_tokens`
--

DROP TABLE IF EXISTS `tb_tokens`;
CREATE TABLE `tb_tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hash` varchar(255) NOT NULL,
  `username` varchar(120) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tb_tokens`
--

/*!40000 ALTER TABLE `tb_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_tokens` ENABLE KEYS */;


--
-- Definition of table `tb_user_rules`
--

DROP TABLE IF EXISTS `tb_user_rules`;
CREATE TABLE `tb_user_rules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `active` tinyint NOT NULL DEFAULT '1',
  `excluded` tinyint NOT NULL DEFAULT '0',
  `subscription_id` int DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_user_rules`
--

/*!40000 ALTER TABLE `tb_user_rules` DISABLE KEYS */;
INSERT INTO `tb_user_rules` (`id`,`uuid`,`name`,`active`,`excluded`,`subscription_id`,`created_at`,`updated_at`,`deleted_at`,`last_updated`) VALUES 
 (1,'45f255f6-71a5-11ee-abee-f60ae0659f4b','Administrador',1,0,0,'2023-10-23 13:08:35','2023-10-23 13:08:35',NULL,'2023-10-23 13:08:35');
/*!40000 ALTER TABLE `tb_user_rules` ENABLE KEYS */;


--
-- Definition of trigger `insert_uuid_tb_user_rules`
--

DROP TRIGGER /*!50030 IF EXISTS */ `insert_uuid_tb_user_rules`;

DELIMITER $$

CREATE DEFINER = `usrfscais`@`%` TRIGGER `insert_uuid_tb_user_rules` BEFORE INSERT ON `tb_user_rules` FOR EACH ROW BEGIN
  IF new.uuid IS NULL THEN
    SET new.uuid = uuid();
  END IF;
END $$

DELIMITER ;

--
-- Definition of table `tb_users`
--

DROP TABLE IF EXISTS `tb_users`;
CREATE TABLE `tb_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `username` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `userpass` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '',
  `first_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '',
  `last_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '',
  `email` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '',
  `phonenumber` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '',
  `whatsappnumber` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '',
  `level` int NOT NULL DEFAULT '1',
  `state` int NOT NULL DEFAULT '1',
  `active` tinyint NOT NULL DEFAULT '1',
  `excluded` tinyint NOT NULL DEFAULT '0',
  `title_function_id` int DEFAULT '0',
  `subscription_id` int DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_users`
--

/*!40000 ALTER TABLE `tb_users` DISABLE KEYS */;
INSERT INTO `tb_users` (`id`,`uuid`,`username`,`userpass`,`first_name`,`last_name`,`email`,`phonenumber`,`whatsappnumber`,`avatar`,`level`,`state`,`active`,`excluded`,`title_function_id`,`subscription_id`,`created_at`,`updated_at`,`deleted_at`,`last_updated`) VALUES 
 (1,'d9d3a90f-71a1-11ee-abee-f60ae0659f4b','sysadmin','admin','Fabrica','Software','fs@fs.com','','','',1,1,1,0,0,0,'2023-10-23 12:44:05','2023-11-17 17:25:11',NULL,'2023-11-17 17:25:11'),
 (2,'214ba16d-72c5-11ee-abee-f60ae0659f4b','sysoperador','opera','Operador','Fatec','fabrica@fatec.sp.gov.br','','','',1,1,1,0,0,0,'2023-10-24 23:29:08','2023-10-26 19:57:14',NULL,'2023-10-26 19:57:14');
/*!40000 ALTER TABLE `tb_users` ENABLE KEYS */;


--
-- Definition of trigger `insert_uuid_tb_users`
--

DROP TRIGGER /*!50030 IF EXISTS */ `insert_uuid_tb_users`;

DELIMITER $$

CREATE DEFINER = `usrfscais`@`%` TRIGGER `insert_uuid_tb_users` BEFORE INSERT ON `tb_users` FOR EACH ROW BEGIN
  IF new.uuid IS NULL THEN
    SET new.uuid = uuid();
  END IF;
END $$

DELIMITER ;



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
