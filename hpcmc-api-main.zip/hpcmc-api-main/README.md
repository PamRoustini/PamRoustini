## Project 
This is the API of the CAIS application of the Fatec Botucatu-Sp Fábrica de Software project

### Version Application
0.0.1

## Description
This application was built using the framework Nest.js

## Requirements
- [Visual Code](https://code.visualstudio.com/download) All platforms
- [Node.js](https://nodejs.org/download/release/v16.20.2/node-v16.20.2-x64.msi) Window Version 16.20
- [Mysql Server](https://dev.mysql.com/get/Downloads/MySQL-5.7/mysql-5.7.44-winx64.zip) Windows Version 5.7.4
- [Mysql Workbench](https://dev.mysql.com/downloads/workbench/) All pltaforms
- [Git](https://git-scm.com/downloads) Version 2.3.9 or greater

#### Setup Mysql Local

- User: usrfscais
- Password: master@fs
- Load file script database in base/BaseCAISFS-V1.sql

Note: If you prefer to use a user that already exists, change the project configuration files.

## Installation of dependencies project

```bash
$ npm install
```

## Running the app

```bash
# development watch mode
$ npm run start:dev

# development
$ npm run start

# production mode
$ npm run start:prod
```

## Test

```bash
# unit tests
$ npm run test

# e2e tests
$ npm run test:e2e

# test coverage
$ npm run test:cov
```

## Support

...

## Stay in touch

- Author - Squad Fatec Fábrica de Software
- Website - [https://...](https://.../)

## License

Is [MIT licensed](LICENSE).
